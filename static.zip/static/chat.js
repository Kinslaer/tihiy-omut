// ========== ГЛОБАЛЬНЫЕ ПЕРЕМЕННЫЕ ==========
let currentUser = null;
let currentChatWith = null;
let ws = null;
let messageHistory = {};

// ========== ПРОВЕРКА АВТОРИЗАЦИИ ==========
currentUser = localStorage.getItem('currentUser');
if (!currentUser) {
    window.location.href = '/static/login.html';
}

// ========== ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ==========
function formatTime() {
    const now = new Date();
    return now.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// ========== ОТРИСОВКА СООБЩЕНИЙ ==========
function renderMessages() {
    const messagesArea = document.getElementById('messagesArea');
    if (!currentChatWith) {
        messagesArea.innerHTML = '<div style="text-align:center;color:#666;margin-top:20px;">Выберите собеседника</div>';
        return;
    }
    
    const messages = messageHistory[currentChatWith] || [];
    if (messages.length === 0) {
        messagesArea.innerHTML = '<div style="text-align:center;color:#666;margin-top:20px;">Нет сообщений. Напишите что-нибудь!</div>';
        return;
    }
    
    messagesArea.innerHTML = messages.map(msg => `
        <div class="message ${msg.sender === currentUser ? 'outgoing' : 'incoming'}">
            ${msg.sender !== currentUser ? `<div class="sender">${escapeHtml(msg.sender)}</div>` : ''}
            <div class="text">${escapeHtml(msg.text)}</div>
            <div class="time">${msg.time}</div>
        </div>
    `).join('');
    
    messagesArea.scrollTop = messagesArea.scrollHeight;
}

// ========== ОТРИСОВКА СПИСКА ПОЛЬЗОВАТЕЛЕЙ ==========
function renderUsers(onlineUsers) {
    const usersList = document.getElementById('usersList');
    fetch('/api/users')
        .then(res => res.json())
        .then(data => {
            const allUsers = data.users.filter(u => u !== currentUser);
            usersList.innerHTML = allUsers.map(user => `
                <div class="user-item ${onlineUsers.includes(user) ? 'online' : ''} ${currentChatWith === user ? 'active' : ''}" 
                     onclick="selectUser('${user}')">
                    ${escapeHtml(user)}
                </div>
            `).join('');
        });
}

// ========== ВЫБОР СОБЕСЕДНИКА ==========
window.selectUser = function(username) {
    currentChatWith = username;
    document.querySelectorAll('.user-item').forEach(el => el.classList.remove('active'));
    event.target.classList.add('active');
    renderMessages();
};

// ========== ОТПРАВКА СООБЩЕНИЯ ==========
function sendMessage() {
    const input = document.getElementById('messageInput');
    const text = input.value.trim();
    if (!text || !currentChatWith) return;
    
    const message = {
        type: "private",
        to: currentChatWith,
        message: text,
        timestamp: formatTime()
    };
    ws.send(JSON.stringify(message));
    
    if (!messageHistory[currentChatWith]) messageHistory[currentChatWith] = [];
    messageHistory[currentChatWith].push({
        sender: currentUser,
        text: text,
        time: formatTime()
    });
    renderMessages();
    
    input.value = '';
}

// ========== WEBSOCKET ==========
function connectWebSocket() {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    ws = new WebSocket(`${protocol}//${window.location.host}/ws/${currentUser}`);
    
    ws.onopen = () => {
        console.log("WebSocket подключен");
        setInterval(() => {
            if (ws && ws.readyState === WebSocket.OPEN) {
                ws.send(JSON.stringify({ type: "ping" }));
            }
        }, 30000);
    };
    
    ws.onmessage = (event) => {
        const data = JSON.parse(event.data);
        
        if (data.type === "user_list") {
            renderUsers(data.users);
        } else if (data.type === "private") {
            if (!messageHistory[data.from]) messageHistory[data.from] = [];
            messageHistory[data.from].push({
                sender: data.from,
                text: data.message,
                time: data.timestamp || formatTime()
            });
            if (currentChatWith === data.from) {
                renderMessages();
            }
        } else if (data.type === "pong") {
            console.log("ping-pong");
        }
    };
    
    ws.onclose = () => {
        console.log("WebSocket отключен, переподключение через 3 секунды...");
        setTimeout(() => connectWebSocket(), 3000);
    };
}

// ========== ВЫХОД ==========
function logout() {
    if (ws) ws.close();
    localStorage.removeItem('currentUser');
    window.location.href = '/static/index.html';
}

// ========== ИНИЦИАЛИЗАЦИЯ ==========
connectWebSocket();

document.getElementById('sendBtn').onclick = sendMessage;
document.getElementById('messageInput').onkeypress = (e) => {
    if (e.key === 'Enter') sendMessage();
};
document.getElementById('logoutBtn').onclick = logout;